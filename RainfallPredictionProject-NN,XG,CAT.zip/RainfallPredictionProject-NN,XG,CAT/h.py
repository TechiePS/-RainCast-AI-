import pandas as pd
import os

# Path for the CSV files
csv_folder_path = r'C:\Users\Admin\Downloads\b60\b60\csv files'

# List to hold DataFrames for each city's data
city_data = {}

# Loop through each year from 2000 to 2023
for year in range(2000, 2024):
    # Construct the file name for each year's CSV
    file_name = f'rainfall_data_{year}.csv'
    file_path = os.path.join(csv_folder_path, file_name)
    
    # Read the CSV file
    if os.path.exists(file_path):
        df = pd.read_csv(file_path)
        # Add a Year column
        df['Year'] = year
        
        # Combine data for each city
        for city in df['City'].unique():
            if city not in city_data:
                city_data[city] = pd.DataFrame()  # Create a new DataFrame for the city
            city_data[city] = pd.concat([city_data[city], df[df['City'] == city]], ignore_index=True)
    else:
        print(f"File not found: {file_path}")

# Now save the combined data for each city to a separate CSV file
for city, data in city_data.items():
    output_file_path = os.path.join(csv_folder_path, f'rainfall_data_{city.replace(" ", "_")}_2000_to_2023.csv')
    data.to_csv(output_file_path, index=False)

print("Combined rainfall data saved for each city from 2000 to 2023.")
