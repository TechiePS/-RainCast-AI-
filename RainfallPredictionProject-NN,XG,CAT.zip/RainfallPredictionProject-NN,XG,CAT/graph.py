
import matplotlib.pyplot as plt
import numpy as np

# # Model names
# models = ['Neural Network', 'LSTM', 'XGBoost', 'CatBoost']

# # RMSE, MAE, and R² values for each model
# rmse_values = [0.04, 0.01, 0.02, 0.02]
# mae_values = [0.03, 0.01, 0.01, 0.01]
# r2_values = [-2.04, 0.63, 0.26, 0.50]

# # Plotting the graph
# fig, ax = plt.subplots(figsize=(10, 6))

# # Plot RMSE, MAE, and R²
# ax.plot(models, rmse_values, marker='o', label='RMSE', color='b')
# ax.plot(models, mae_values, marker='o', label='MAE', color='g')
# ax.plot(models, r2_values, marker='o', label='R²', color='r')

# # Add titles and labels
# ax.set_title('Model Accuracy Comparison', fontsize=14)
# ax.set_xlabel('Models', fontsize=12)
# ax.set_ylabel('Accuracy Metrics', fontsize=12)
# ax.legend()

# # Display the plot
# plt.grid(True)
# plt.tight_layout()
# plt.show()





# Data for the graphs
models = ['Neural Network', 'LSTM', 'XGBoost', 'CatBoost']
rmse_values = [0.04, 0.01, 0.02, 0.02]
mae_values = [0.03, 0.01, 0.01, 0.01]
r2_values = [-2.04, 0.63, 0.26, 0.50]

# Create subplots for 5 different graphs
fig, axs = plt.subplots(3, 2, figsize=(12, 12))
fig.suptitle('Model Accuracy Overview for General Audience', fontsize=16)

# 1. Simple Accuracy Comparison (lower RMSE and MAE is better, higher R2 is better)
simple_accuracy = [1/rmse_values[i] + 1/mae_values[i] + (r2_values[i] if r2_values[i] > 0 else 0) for i in range(4)]
axs[0, 0].bar(models, simple_accuracy, color=['b', 'g', 'r', 'c'])
axs[0, 0].set_title('Simple Model Accuracy (higher is better)')
axs[0, 0].set_ylabel('Score')

# 2. RMSE Comparison
axs[0, 1].bar(models, rmse_values, color='b')
axs[0, 1].set_title('RMSE Comparison (lower is better)')
axs[0, 1].set_ylabel('RMSE')

# 3. MAE Comparison
axs[1, 0].bar(models, mae_values, color='g')
axs[1, 0].set_title('MAE Comparison (lower is better)')
axs[1, 0].set_ylabel('MAE')

# 4. R² Score Comparison
axs[1, 1].bar(models, r2_values, color='r')
axs[1, 1].set_title('R² Comparison (higher is better)')
axs[1, 1].set_ylabel('R² Score')

# 5. Combined Performance Overview
width = 0.2  # width of the bars
x = np.arange(len(models))
axs[2, 0].bar(x - width, rmse_values, width, label='RMSE', color='b')
axs[2, 0].bar(x, mae_values, width, label='MAE', color='g')
axs[2, 0].bar(x + width, r2_values, width, label='R²', color='r')
axs[2, 0].set_title('Model Performance Overview')
axs[2, 0].set_xticks(x)
axs[2, 0].set_xticklabels(models)
axs[2, 0].set_ylabel('Metric Value')
axs[2, 0].legend()

# Hide the unused subplot
axs[2, 1].axis('off')

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()
