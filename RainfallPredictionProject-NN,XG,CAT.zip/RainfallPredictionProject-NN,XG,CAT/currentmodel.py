# BEST PERFOMING MODEL TILL NOW

import pandas as pd
import numpy as np
import tensorflow as tf
from keras.models import Sequential
from keras.layers import BatchNormalization, LSTM, Dense, Dropout, Input, LeakyReLU
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import xgboost as xgb
from catboost import CatBoostRegressor

# Load dataset
data_path = r'D:\rainfall\combined_rainfall_data_2000_to_2023.csv'  # Update this path
rainfall_data = pd.read_csv(data_path)

# Check for NaN values
if rainfall_data.isnull().values.any():
    print("Data contains NaN values. Dropping NaNs...")
    rainfall_data = rainfall_data.dropna()

# Preprocessing function
def preprocess_data(df):
    # Specify the correct date format
    df['Date'] = pd.to_datetime(df['Date'], format='%d/%m/%Y %H:%M', errors='coerce')

    # Check for any NaT values after conversion
    if df['Date'].isnull().any():
        print("Some dates could not be parsed and will be dropped.")
        df = df.dropna(subset=['Date'])

    df['Year'] = df['Date'].dt.year
    df['Month'] = df['Date'].dt.month
    df['Day'] = df['Date'].dt.day
    df['Season'] = df['Month'].apply(lambda x: 'Winter' if x in [12, 1, 2] else
                                       'Spring' if x in [3, 4, 5] else
                                       'Summer' if x in [6, 7, 8] else
                                       'Fall')

    # Create cyclical features
    df['Month_sin'] = np.sin(2 * np.pi * df['Month'] / 12)
    df['Month_cos'] = np.cos(2 * np.pi * df['Month'] / 12)
    df['Day_sin'] = np.sin(2 * np.pi * df['Day'] / 31)
    df['Day_cos'] = np.cos(2 * np.pi * df['Day'] / 31)

    df = df.drop(columns='Date')
    scaler = MinMaxScaler()
    df['Rainfall (mm)'] = scaler.fit_transform(df[['Rainfall (mm)']])
    return df, scaler


# Preprocess data
rainfall_data, scaler = preprocess_data(rainfall_data)

# Neural Network model function
def train_neural_network(city_name, df):
    city_data = df[df['City'].str.lower() == city_name.lower()].copy()
    city_data = city_data.drop(columns='City')

    # Adding lag features
    city_data['Lag1'] = city_data['Rainfall (mm)'].shift(1)
    city_data['Lag2'] = city_data['Rainfall (mm)'].shift(2)
    city_data = city_data.dropna()  # Drop NaN values after creating lag features

    X = city_data[['Year', 'Month', 'Day', 'Lag1', 'Lag2']]
    y = city_data['Rainfall (mm)']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = Sequential([
        Input(shape=(X_train.shape[1],)),
        Dense(128, activation='relu'),
        BatchNormalization(),
        Dropout(0.3),
        Dense(64),
        BatchNormalization(),
        LeakyReLU(alpha=0.1),
        Dropout(0.3),
        Dense(32),
        Dense(1)
    ])
    model.compile(optimizer='adam', loss='mean_squared_error')
    model.fit(X_train, y_train, epochs=150, batch_size=32, verbose=1, validation_split=0.1)

    return model, X_test, y_test

# Function to train the LSTM model
def train_lstm_model(city_name, df):
    city_data = df[df['City'] == city_name]['Rainfall (mm)'].values

    # Check for NaN values
    if np.isnan(city_data).any():
        city_data = city_data[~np.isnan(city_data)]

    # Prepare the dataset
    X, y = [], []
    for i in range(30, len(city_data)):
        X.append(city_data[i-30:i])
        y.append(city_data[i])

    X_train, y_train = np.array(X), np.array(y)

    # Reshape for LSTM [samples, time steps, features]
    X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))

    # Build the LSTM model
    model = Sequential()
    model.add(LSTM(100, activation='relu', return_sequences=True, input_shape=(X_train.shape[1], 1)))
    model.add(Dropout(0.2))
    model.add(LSTM(50, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse')

    # Train the model
    model.fit(X_train, y_train, epochs=200, batch_size=32, verbose=1)

    return model, X_train, y_train

# Function to train the XGBoost model
def train_xgboost_model(city_name, df):
    city_data = df[df['City'].str.lower() == city_name.lower()].copy()
    city_data = city_data.drop(columns='City')

    # Add lag features
    city_data['Lag1'] = city_data['Rainfall (mm)'].shift(1)
    city_data['Lag2'] = city_data['Rainfall (mm)'].shift(2)
    city_data = city_data.dropna()

    X = city_data[['Year', 'Month', 'Day', 'Lag1', 'Lag2']]
    y = city_data['Rainfall (mm)']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = xgb.XGBRegressor(objective='reg:squarederror', n_estimators=200)
    model.fit(X_train, y_train)

    return model, X_test, y_test

# Function to train the CatBoost model
def train_catboost_model(city_name, df):
    city_data = df[df['City'].str.lower() == city_name.lower()].copy()
    city_data = city_data.drop(columns='City')

    # Add lag features
    city_data['Lag1'] = city_data['Rainfall (mm)'].shift(1)
    city_data['Lag2'] = city_data['Rainfall (mm)'].shift(2)
    city_data = city_data.dropna()

    X = city_data[['Year', 'Month', 'Day', 'Lag1', 'Lag2']]
    y = city_data['Rainfall (mm)']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = CatBoostRegressor(iterations=200, depth=8, learning_rate=0.05, loss_function='RMSE', silent=True)
    model.fit(X_train, y_train)

    return model, X_test, y_test

# Function to evaluate models
def evaluate_models(models, X_test, y_test, lstm_X, lstm_y):
    for model_name, model in models.items():
        if model_name == 'LSTM':
            y_pred = model.predict(lstm_X)
            rmse = np.sqrt(mean_squared_error(lstm_y, y_pred))
            mae = mean_absolute_error(lstm_y, y_pred)
            r2 = r2_score(lstm_y, y_pred)
        else:
            y_pred = model.predict(X_test)
            rmse = np.sqrt(mean_squared_error(y_test, y_pred))
            mae = mean_absolute_error(y_test, y_pred)
            r2 = r2_score(y_test, y_pred)

        print(f"{model_name} - RMSE: {rmse:.2f}, MAE: {mae:.2f}, R-squared: {r2:.2f}")

# Updated function to predict rainfall and chance of rain
def predict_rainfall(model, year, month, day, scaler, last_rainfall):
    # Prepare input with lag values set to last_rainfall
    input_data = np.array([[year, month, day, last_rainfall, last_rainfall]])

    # Make prediction
    prediction = model.predict(input_data).flatten()[0]

    # Inverse transform the predicted rainfall
    predicted_rainfall = scaler.inverse_transform(np.array([[prediction]]))[0][0]

    rain_threshold = 1.0  # Adjusted threshold for rain
    chance_of_rain = min(100, max(0, (predicted_rainfall / rain_threshold) * 100))

    return predicted_rainfall, chance_of_rain

# Main interface for user input
def user_interface(df):
    cities = df['City'].unique()
    print("Available cities: ", ', '.join(cities))
    selected_city = input("Please enter a city name: ").strip()

    if selected_city not in cities:
        print("Invalid city name. Please try again.")
        return

    models = {}

    # Train models for selected city
    nn_model, X_test, y_test = train_neural_network(selected_city, df)
    xgb_model, _, _ = train_xgboost_model(selected_city, df)
    catboost_model, _, _ = train_catboost_model(selected_city, df)

    lstm_model, lstm_X, lstm_y = train_lstm_model(selected_city, df)

    models = {
        'Neural Network': nn_model,
        'LSTM': lstm_model,
        'XGBoost': xgb_model,
        'CatBoost': catboost_model
    }

    # Evaluate models
    evaluate_models(models, X_test, y_test, lstm_X, lstm_y)

    # Get user input for date
    year = int(input("Enter the year (e.g., 2024): "))
    month = int(input("Enter the month (1-12): "))
    day = int(input("Enter the day (1-31): "))

    # Get the last known rainfall value for lag features
    last_rainfall = df[df['City'].str.lower() == selected_city.lower()]['Rainfall (mm)'].iloc[-1]

    # Predict rainfall and chance of rain using the best model (example: Neural Network)
    predicted_rainfall, chance_of_rain = predict_rainfall(nn_model, year, month, day, scaler, last_rainfall)

    print(f"Predicted rainfall for {selected_city} on {day}/{month}/{year}: {predicted_rainfall:.2f} mm")
    print(f"Chance of rain: {chance_of_rain:.2f}%")

# Run the user interface
user_interface(rainfall_data)
