import netCDF4 as nc
import numpy as np
import pandas as pd
import os

# Base path for the NetCDF files
base_path = r'C:\Users\Admin\Downloads\b60\b60\nc files - Copy'

# List of years
years = range(2000, 2024)

# List of cities with their coordinates
cities = {
    "Agra": (27.1767, 78.0081),
    "Ahmedabad": (23.0225, 72.5714),
    "Ahmednagar": (19.0983, 74.7380),
    "Ajmer": (26.4499, 74.6399),
    "Akola": (20.7062, 77.0000),
    "Aligarh": (27.8861, 78.0774),
    "Alwar": (27.5759, 76.6350),
    "Ambala": (30.3785, 76.7800),
    "Anantapur": (14.6812, 77.6000),
    "Aurangabad": (19.8762, 75.3433),
    "Aurangabad (Maharashtra)": (19.8762, 75.3433),
    "Baddi": (30.9356, 76.7463),
    "Ballari": (15.1394, 76.9200),
    "Bareilly": (28.3667, 79.4333),
    "Belgaum": (15.8667, 74.5000),
    "Bhavnagar": (21.7667, 72.1500),
    "Bhiwandi": (19.3000, 73.0500),
    "Bhopal": (23.2500, 77.4167),
    "Bhubaneswar": (20.2644, 85.8281),
    "Bikaner": (28.0167, 73.3167),
    "Bilaspur": (22.0833, 82.1500),
    "Bokaro Steel City": (23.6833, 86.1500),
    "Chennai": (13.0827, 80.2707),
    "Chhindwara": (22.0631, 78.9306),
    "Coimbatore": (11.0168, 76.9558),
    "Cuttack": (20.4667, 85.8833),
    "Dehradun": (30.3165, 78.0322),
    "Deoghar": (24.4875, 86.7031),
    "Dhanbad": (23.7989, 86.4444),
    "Durg-Bhilai": (21.2167, 81.3500),
    "Durgapur": (23.5500, 87.3167),
    "Eluru": (16.7061, 81.1000),
    "Erode": (11.3411, 77.7339),
    "Faridabad": (28.4089, 77.3178),
    "Firozabad": (27.1500, 78.4000),
    "Ghaziabad": (28.6667, 77.4167),
    "Gorakhpur": (26.7612, 83.3731),
    "Gulbarga": (17.3333, 76.8333),
    "Guntur": (16.3000, 80.4500),
    "Guwahati": (26.1445, 91.7362),
    "Hamirpur": (31.6833, 76.5167),
    "Hubli-Dharwad": (15.3667, 75.1167),
    "Indore": (22.7206, 75.8472),
    "Jabalpur": (23.1667, 79.9500),
    "Jaisalmer": (26.9157, 70.9164),
    "Jalandhar": (31.3260, 75.5762),
    "Jamnagar": (22.4667, 70.0667),
    "Jamshedpur": (22.8000, 86.1833),
    "Jhansi": (25.4500, 78.5667),
    "Jodhpur": (26.2389, 73.0243),
    "Kakinada": (16.9333, 82.2333),
    "Kalyan-Dombivli": (19.2183, 73.1528),
    "Kannur": (11.8725, 75.3704),
    "Kanpur": (26.4499, 80.3319),
    "Kota": (25.1828, 75.8648),
    "Kochi": (9.9312, 76.2673),
    "Kolkata": (22.5726, 88.3639),
    "Kurukshetra": (29.9439, 76.8305),
    "Lucknow": (26.8467, 80.9462),
    "Ludhiana": (30.9009, 75.8573),
    "Madurai": (9.9258, 78.1198),
    "Mangaluru": (12.9141, 74.8559),
    "Meerut": (28.9845, 77.7064),
    "Nagpur": (21.1458, 79.0882),
    "Nanded": (19.1506, 77.3090),
    "Nashik": (19.9975, 73.7898),
    "Noida": (28.5355, 77.3910),
    "Patiala": (30.3341, 76.3855),
    "Pimpri-Chinchwad": (17.1232, 73.7998),
    "Pune": (18.5204, 73.8567),
    "Raipur": (21.2514, 81.6296),
    "Ranchi": (23.3441, 85.3096),
    "Rajkot": (22.3039, 70.2400),
    "Rourkela": (22.2587, 84.8375),
    "Solapur": (17.6833, 75.9063),
    "Surat": (21.1702, 72.8311),
    "Thane": (19.2183, 72.9781),
    "Thiruvananthapuram": (8.5241, 76.9366),
    "Vadodara": (22.3072, 73.1812),
    "Varanasi": (25.3176, 82.9739),
    "Visakhapatnam": (17.6868, 83.2185),
    "Vasai-Virar": (19.3050, 73.0000),
    "Zirakpur": (30.6492, 76.8511),
}

# Function to find the nearest grid point for a city
def find_nearest(lat, lon):
    lat_idx = (np.abs(latitudes - lat)).argmin()
    lon_idx = (np.abs(longitudes - lon)).argmin()
    return lat_idx, lon_idx

# Loop through each year and process the respective NetCDF file
for year in years:
    # Construct the file path for the NetCDF file
    file_name = f'RF25_ind{year}_rfp25.nc'
    file_path = os.path.join(base_path, file_name)

    # Load the NetCDF file
    dataset = nc.Dataset(file_path)

    # Access the rainfall variable (assuming this is 3D: (time, lat, lon))
    rainfall_data = dataset.variables['RAINFALL'][:]  # Adjust if necessary

    # Get the latitude and longitude variables
    latitudes = dataset.variables['LATITUDE'][:]  # Adjusted variable name
    longitudes = dataset.variables['LONGITUDE'][:]  # Adjusted variable name

    # Get the time variable
    time_data = dataset.variables['TIME'][:]  # Get time data
    # Convert time to dates
    dates = nc.num2date(time_data, units=dataset.variables['TIME'].units)

    # Create a list to store DataFrames for each city
    rainfall_data_list = []

    # Loop through each city and extract rainfall data
    for city, (lat, lon) in sorted(cities.items()):
        city_idx = find_nearest(lat, lon)
        
        # Extract rainfall data for the city
        city_rainfall = rainfall_data[:, city_idx[0], city_idx[1]]  # Extract rainfall data for the city
        
        # Create a DataFrame for the city's rainfall data
        city_rainfall_df = pd.DataFrame({
            "City": city,
            "Date": dates,
            "Rainfall (mm)": city_rainfall
        })
        
        # Append the DataFrame to the list
        rainfall_data_list.append(city_rainfall_df)

    # Concatenate all city DataFrames into a single DataFrame
    rainfall_results = pd.concat(rainfall_data_list, ignore_index=True)

    # Save results to a CSV file
    output_file_path = os.path.join(base_path, f'rainfall_data_{year}.csv')
    rainfall_results.to_csv(output_file_path, index=False)

    print(f"Rainfall data extraction for {year} complete. Results saved to '{output_file_path}'.")
