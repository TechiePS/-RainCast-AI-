import pandas as pd
import os

# Path for the city-wise CSV files
city_csv_folder_path = r'C:\Users\Admin\Downloads\b60\b60\csv files\citywise'

# List of city names (adjust the names in case of spaces or other characters in file names)
city_names = [
    "Agra", "Ahmedabad", "Ahmednagar", "Ajmer", "Akola", "Aligarh", "Alwar",
    "Ambala", "Anantapur", "Aurangabad", "Baddi", "Ballari", "Bareilly",
    "Belgaum", "Bhavnagar", "Bhiwandi", "Bhopal", "Bhubaneswar", "Bikaner",
    "Bilaspur", "Bokaro Steel City", "Chennai", "Chhindwara", "Coimbatore",
    "Cuttack", "Dehradun", "Deoghar", "Dhanbad", "Durg-Bhilai", "Durgapur",
    "Eluru", "Erode", "Faridabad", "Firozabad", "Ghaziabad", "Gorakhpur",
    "Gulbarga", "Guntur", "Guwahati", "Hamirpur", "Hubli-Dharwad", "Indore",
    "Jabalpur", "Jaisalmer", "Jalandhar", "Jamnagar", "Jamshedpur", "Jhansi",
    "Jodhpur", "Kakinada", "Kalyan-Dombivli", "Kannur", "Kanpur", "Kota",
    "Kochi", "Kolkata", "Kurukshetra", "Lucknow", "Ludhiana", "Madurai",
    "Mangaluru", "Meerut", "Nagpur", "Nanded", "Nashik", "Noida", "Patiala",
    "Pimpri-Chinchwad", "Pune", "Raipur", "Ranchi", "Rajkot", "Rourkela",
    "Solapur", "Surat", "Thane", "Thiruvananthapuram", "Vadodara", "Varanasi",
    "Visakhapatnam", "Vasai-Virar", "Zirakpur"
]

# List to hold DataFrames for all cities
all_city_dataframes = []

# Loop through each city name
for city in city_names:
    # Construct the file name
    file_name = f'rainfall_data_{city.replace(" ", "_")}_2000_to_2023.csv'
    file_path = os.path.join(city_csv_folder_path, file_name)
    
    # Read the CSV file
    if os.path.exists(file_path):
        df = pd.read_csv(file_path)
        df['City'] = city  # Add a column for the city name
        all_city_dataframes.append(df)
    else:
        print(f"File not found: {file_path}")

# Concatenate all DataFrames into a single DataFrame
combined_rainfall_data = pd.concat(all_city_dataframes, ignore_index=True)

# Save the combined DataFrame to a new CSV file
output_combined_file_path = os.path.join(city_csv_folder_path, 'combined_rainfall_data_2000_to_2023.csv')
combined_rainfall_data.to_csv(output_combined_file_path, index=False)

print(f"Combined rainfall data saved to '{output_combined_file_path}'.")
