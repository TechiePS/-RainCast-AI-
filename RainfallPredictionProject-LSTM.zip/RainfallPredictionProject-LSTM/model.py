import pandas as pd
import numpy as np
import pickle
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout

# Preprocess data
def preprocess_data(data_path):
    rainfall_data = pd.read_csv(data_path)
    rainfall_data.dropna(inplace=True)
    scaler = MinMaxScaler()
    rainfall_data['Rainfall (mm)'] = scaler.fit_transform(rainfall_data[['Rainfall (mm)']])
    return rainfall_data, scaler

# Prepare the LSTM model
def prepare_model(city_name, data_path = 'D:\\rainfall\\combined_rainfall_data_2000_to_2023.csv'):
    rainfall_data, scaler = preprocess_data(data_path)
    city_data = rainfall_data[rainfall_data['City'].str.lower() == city_name.lower()].copy()

    if city_data.empty:
        raise ValueError(f"No data available for city: {city_name}")

    city_data.drop(columns='City', inplace=True)

    # Creating lag features
    city_data['Lag1'] = city_data['Rainfall (mm)'].shift(1)
    city_data['Lag2'] = city_data['Rainfall (mm)'].shift(2)
    city_data.dropna(inplace=True)

    X, y = [], []
    for i in range(30, len(city_data)):
        X.append(city_data.iloc[i-30:i][['Lag1', 'Lag2']].values)
        y.append(city_data['Rainfall (mm)'].iloc[i])

    X, y = np.array(X), np.array(y)

    # Build the LSTM model
    model = Sequential()
    model.add(LSTM(100, activation='relu', return_sequences=True, input_shape=(X.shape[1], X.shape[2])))
    model.add(Dropout(0.2))
    model.add(LSTM(50, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse')

    # Train the model
    model.fit(X, y, epochs=200, batch_size=32, verbose=0)

    # Save the model
    with open(f'{city_name.lower()}_lstm_model.pkl', 'wb') as f:
        pickle.dump(model, f)

# Load the trained LSTM model
def load_model(city_name):
    with open(f'{city_name.lower()}_lstm_model.pkl', 'rb') as f:
        model = pickle.load(f)
    return model

# Function to predict rainfall
def predict_rainfall(model, last_rainfall):
    input_data = np.array([[last_rainfall, last_rainfall]])
    input_data = input_data.reshape((1, 1, 2))

    prediction = model.predict(input_data).flatten()[0]
    return max(0, prediction)  # Ensure non-negative prediction
